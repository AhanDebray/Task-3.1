package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity_3 extends AppCompatActivity {

    TextView cUser, points;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_3);
        cUser = findViewById(R.id.textView6);
        points = findViewById(R.id.textView8);

        Intent intent_2 = getIntent();
        int score = intent_2.getIntExtra("SCORE",2);
        String user = intent_2.getStringExtra("Username") ;
        points.setText(score + " / " + "6" );
        cUser.setText("Congratulations " + user);
    }
    public void finish(View view)
    {
        finish();
        moveTaskToBack(true);
    }
    public void new_Quiz(View view)
    {
        Intent intent = getIntent();
        Intent intent_3 = new Intent(this, MainActivity.class);
        intent_3.putExtra("Username",intent.getStringExtra("Username"));
        startActivity(intent_3);
    }
}