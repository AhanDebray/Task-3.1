package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity_2 extends AppCompatActivity {

    TextView questionNumber,question;
    int level = 1, score = 0;
    ProgressBar progress;
    int q1, q2, q3, q4, q5,q6;
    Button option1,option2,option3,option4,option5,option6,option7,option8,option9,option10,option11,option12,option13,option14,option15,option16,option17,option18;
    Button submit,next1,next2,next3,next4,next5,next6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_2);
        questionNumber = findViewById(R.id.textView4);
        question = findViewById(R.id.textView5);
        progress = findViewById(R.id.progressBar);

        option1 = findViewById(R.id.button2);
        option2 = findViewById(R.id.button3);
        option3 = findViewById(R.id.button4);
        next1 = findViewById(R.id.nextButton);

        option4 = findViewById(R.id.button5);
        option5 = findViewById(R.id.button6);
        option6 = findViewById(R.id.button7);
        next2 = findViewById(R.id.nextButton2);

        option7 = findViewById(R.id.button8);
        option8 = findViewById(R.id.button9);
        option9 = findViewById(R.id.button10);
        next3 = findViewById(R.id.nextButton3);

        option10 = findViewById(R.id.button11);
        option11 = findViewById(R.id.button12);
        option12 = findViewById(R.id.button13);
        next4 = findViewById(R.id.nextButton4);

        option13 = findViewById(R.id.button14);
        option14 = findViewById(R.id.button15);
        option15 = findViewById(R.id.button16);
        next5 = findViewById(R.id.nextButton5);

        option16 = findViewById(R.id.button17);
        option17 = findViewById(R.id.button18);
        option18 = findViewById(R.id.button19);
        next6 = findViewById(R.id.nextButton6);
        submit = findViewById(R.id.submit_button);

        Intent intent = getIntent();
        String user = intent.getStringExtra("Username");

        option1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q1 = 1;
            }
        });
        option2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q1 = 2;
            }
        });
        option3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q1 = 3;
            }
        });
        option4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q2 = 1;
            }
        });
        option5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q2 = 2;
            }
        });
        option6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q2 = 3;
            }
        });
        option7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q3 = 1;
            }
        });
        option8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q3 = 2;
            }
        });
        option9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q3 = 3;
            }
        });
        option10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q4 = 1;
            }
        });
        option11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q4 = 2;
            }
        });
        option12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q4 = 3;
            }
        });
        option13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q5 = 1;
            }
        });
        option14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q5 = 2;
            }
        });
        option15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q5 = 3;
            }
        });
        option16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q6 = 1;
            }
        });
        option17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q6 = 2;
            }
        });
        option18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                q6 = 3;
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (q1 == 1) {
                    option1.setBackgroundColor(Color.RED);
                    option2.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next1.setEnabled(true);
                    next1.setVisibility(View.VISIBLE);
                }
                else if (q1 == 2) {
                    option2.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next1.setEnabled(true);
                    next1.setVisibility(View.VISIBLE);
                }
                else if (q1 == 3) {
                    option3.setBackgroundColor(Color.RED);
                    option2.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next1.setEnabled(true);
                    next1.setVisibility(View.VISIBLE);
                    score++;
                }
                else if (q2 == 1) {
                    option4.setBackgroundColor(Color.RED);
                    option5.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next2.setEnabled(true);
                    next2.setVisibility(View.VISIBLE);
                }
                else if (q2 == 2) {
                    option5.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next2.setEnabled(true);
                    next2.setVisibility(View.VISIBLE);
                    score++;
                }
                else if (q2 == 3) {
                    option6.setBackgroundColor(Color.RED);
                    option5.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next2.setEnabled(true);
                    next2.setVisibility(View.VISIBLE);
                }
                else if (q3 == 1) {
                    option7.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next3.setEnabled(true);
                    next3.setVisibility(View.VISIBLE);
                    score++;
                }
                else if (q3 == 2) {
                    option8.setBackgroundColor(Color.RED);
                    option7.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next3.setEnabled(true);
                    next3.setVisibility(View.VISIBLE);
                }
                else if (q3 == 3) {
                    option7.setBackgroundColor(Color.GREEN);
                    option9.setBackgroundColor(Color.RED);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next3.setEnabled(true);
                    next3.setVisibility(View.VISIBLE);
                }
                else if (q4 == 1) {
                    option10.setBackgroundColor(Color.RED);
                    option11.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next4.setEnabled(true);
                    next4.setVisibility(View.VISIBLE);
                }
                else if (q4 == 2) {
                    option11.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next4.setEnabled(true);
                    next4.setVisibility(View.VISIBLE);
                    score++;
                }
                else if (q4 == 3) {
                    option12.setBackgroundColor(Color.RED);
                    option11.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next4.setEnabled(true);
                    next4.setVisibility(View.VISIBLE);
                }
                else if (q5 == 1) {
                    option13.setBackgroundColor(Color.RED);
                    option15.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next5.setEnabled(true);
                    next5.setVisibility(View.VISIBLE);
                }
                else if (q5 == 2) {
                    option14.setBackgroundColor(Color.RED);
                    option15.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next5.setEnabled(true);
                    next5.setVisibility(View.VISIBLE);
                }
                else if (q5 == 3) {
                    option15.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next5.setEnabled(true);
                    next5.setVisibility(View.VISIBLE);
                    score++;
                }
                else if (q6 == 1) {
                    option16.setBackgroundColor(Color.RED);
                    option18.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next6.setEnabled(true);
                    next6.setVisibility(View.VISIBLE);
                }
                else if (q6 == 2) {
                    option17.setBackgroundColor(Color.RED);
                    option18.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next6.setEnabled(true);
                    next6.setVisibility(View.VISIBLE);
                }
                else if (q6 == 3) {
                    option18.setBackgroundColor(Color.GREEN);

                    submit.setEnabled(false);
                    submit.setVisibility(View.INVISIBLE);

                    next6.setEnabled(true);
                    next6.setVisibility(View.VISIBLE);
                    score++;
                }
                else {
                    Toast.makeText(MainActivity_2.this, "You need to select an option", Toast.LENGTH_LONG).show();
                }
            }
        });
        next1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                questionNumber.setText("QUESTION 2");
                question.setText("Which Android Studio file is most of the app coding done in?");

                option1.setEnabled(false);
                option1.setVisibility(View.INVISIBLE);
                option2.setEnabled(false);
                option2.setVisibility(View.INVISIBLE);
                option3.setEnabled(false);
                option3.setVisibility(View.INVISIBLE);

                option4.setEnabled(true);
                option4.setVisibility(View.VISIBLE);
                option5.setEnabled(true);
                option5.setVisibility(View.VISIBLE);
                option6.setEnabled(true);
                option6.setVisibility(View.VISIBLE);

                submit.setEnabled(true);
                submit.setVisibility(View.VISIBLE);
                next1.setEnabled(false);
                next1.setVisibility(View.INVISIBLE);
                progress.setProgress((level + 1));
                q1 = 0;
                level++;
            }
        });
        next2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                questionNumber.setText("QUESTION 3");
                question.setText("Which component property should be changed to a name that is specific of the components use?");
                option4.setEnabled(false);
                option4.setVisibility(View.INVISIBLE);
                option5.setEnabled(false);
                option5.setVisibility(View.INVISIBLE);
                option6.setEnabled(false);
                option6.setVisibility(View.INVISIBLE);

                option7.setEnabled(true);
                option7.setVisibility(View.VISIBLE);
                option8.setEnabled(true);
                option8.setVisibility(View.VISIBLE);
                option9.setEnabled(true);
                option9.setVisibility(View.VISIBLE);

                submit.setEnabled(true);
                submit.setVisibility(View.VISIBLE);
                next2.setEnabled(false);
                next2.setVisibility(View.INVISIBLE);
                progress.setProgress((level + 1));
                q2 = 0;
                level++;
            }
        });
        next3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                questionNumber.setText("QUESTION 4");
                question.setText("What is the system image that the virtual device was set up to support?");
                option7.setEnabled(false);
                option7.setVisibility(View.INVISIBLE);
                option8.setEnabled(false);
                option8.setVisibility(View.INVISIBLE);
                option9.setEnabled(false);
                option9.setVisibility(View.INVISIBLE);

                option10.setEnabled(true);
                option10.setVisibility(View.VISIBLE);
                option11.setEnabled(true);
                option11.setVisibility(View.VISIBLE);
                option12.setEnabled(true);
                option12.setVisibility(View.VISIBLE);

                submit.setEnabled(true);
                submit.setVisibility(View.VISIBLE);
                next3.setEnabled(false);
                next3.setVisibility(View.INVISIBLE);
                progress.setProgress((level + 1));
                q3 = 0;
                level++;
            }
        });
        next4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                questionNumber.setText("QUESTION 5");
                question.setText("What is a GCM in android ?");
                option10.setEnabled(false);
                option10.setVisibility(View.INVISIBLE);
                option11.setEnabled(false);
                option11.setVisibility(View.INVISIBLE);
                option12.setEnabled(false);
                option12.setVisibility(View.INVISIBLE);

                option13.setEnabled(true);
                option13.setVisibility(View.VISIBLE);
                option14.setEnabled(true);
                option14.setVisibility(View.VISIBLE);
                option15.setEnabled(true);
                option15.setVisibility(View.VISIBLE);

                submit.setEnabled(true);
                submit.setVisibility(View.VISIBLE);
                next4.setEnabled(false);
                next4.setVisibility(View.INVISIBLE);
                progress.setProgress((level + 1));
                q4 = 0;
                level++;
            }
        });
        next5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                questionNumber.setText("QUESTION 6");
                question.setText("Which listener is called for the device to register the enter key press?");
                option13.setEnabled(false);
                option13.setVisibility(View.INVISIBLE);
                option14.setEnabled(false);
                option14.setVisibility(View.INVISIBLE);
                option15.setEnabled(false);
                option15.setVisibility(View.INVISIBLE);

                option16.setEnabled(true);
                option16.setVisibility(View.VISIBLE);
                option17.setEnabled(true);
                option17.setVisibility(View.VISIBLE);
                option18.setEnabled(true);
                option18.setVisibility(View.VISIBLE);

                submit.setEnabled(true);
                submit.setVisibility(View.VISIBLE);
                next5.setEnabled(false);
                next5.setVisibility(View.INVISIBLE);
                progress.setProgress((level + 1));
                q5 = 0;
                level++;
            }
        });
    }
    public void Final_Page(View view)
    {
        Intent intent = getIntent();

        Intent intent_2 = new Intent(this, MainActivity_3.class);
        intent_2.putExtra("Score", score);
        intent_2.putExtra("Username",intent.getStringExtra("Username"));

        startActivity(intent_2);
    }
}