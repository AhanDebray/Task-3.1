package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText text;

    public void StartButton(View view)
    {
        Intent intent = new Intent(this, MainActivity_2.class);
        intent.putExtra("Username",text.getText().toString());
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = findViewById(R.id.editText);

        if (text != null)
        {
            Intent intent = getIntent();
            String user = intent.getStringExtra("Username");
            text.setText(user);
        }
    }
}
